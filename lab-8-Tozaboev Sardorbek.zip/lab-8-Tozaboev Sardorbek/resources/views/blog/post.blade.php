@extends('layouts.master')

@section('content')

<div class="row">
        <div class="col-md-12">
            <p class="quote">The beautiful Laravel</p>
        </div>
</div>
<div class="row">
        <div class="col-md-12 text-center">
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Fugiat quas amet et iusto sapiente consequuntur obcaecati voluptatum facere? Dolor facilis vero voluptatem iste laboriosam possimus pariatur magni sint iure animi.Lorem ipsum dolor sit amet, consectetur adipisicing elit. Fugiat quas amet et iusto sapiente consequuntur obcaecati voluptatum facere? Dolor facilis vero voluptatem iste laboriosam possimus pariatur magni sint iure animi.Lorem ipsum dolor sit amet, consectetur adipisicing elit. Fugiat quas amet et iusto sapiente consequuntur obcaecati voluptatum facere? Dolor facilis vero voluptatem iste laboriosam possimus pariatur magni sint iure animi.Lorem ipsum dolor sit amet, consectetur adipisicing elit. Fugiat quas amet et iusto sapiente consequuntur obcaecati voluptatum facere? Dolor facilis vero voluptatem iste laboriosam possimus pariatur magni sint iure animi.</p>
        </div>
 </div>
@endsection